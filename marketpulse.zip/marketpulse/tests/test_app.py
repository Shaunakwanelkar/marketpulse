from streamlit.testing.v1 import AppTest
at = AppTest.from_file("../app.py", default_timeout=180).run()
assert not at.exception, at.exception
print("initial render ok; buttons:", [b.label for b in at.button])
run = [b for b in at.button if "Run analysis" in b.label][0]
run.click().run()
assert not at.exception, at.exception
print("errors:", [e.value for e in at.error][:5])
print("status/info:", [s.label for s in at.status] if hasattr(at,'status') else None)
print("metrics:", [(m.label, m.value) for m in at.metric])
print("markdown sample:", [m.value[:90] for m in at.markdown if "📣" in m.value][:4])
print("text_areas:", len(at.text_area), "dataframes:", len(at.dataframe))
# switch to LDA and template; try a second run with VADER
at.selectbox[0].set_value("VADER (lexicon, no training)").run()
[b for b in at.button if "Run analysis" in b.label][0].click().run()
assert not at.exception, at.exception
print("VADER run ok; metrics:", [(m.label, m.value) for m in at.metric][:3])
